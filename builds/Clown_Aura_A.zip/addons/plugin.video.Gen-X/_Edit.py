import xbmcaddon
import base64
MainBase = base64.b64decode ('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1dYY2I0U1lG')
addon = xbmcaddon.Addon('plugin.video.Gen-X')